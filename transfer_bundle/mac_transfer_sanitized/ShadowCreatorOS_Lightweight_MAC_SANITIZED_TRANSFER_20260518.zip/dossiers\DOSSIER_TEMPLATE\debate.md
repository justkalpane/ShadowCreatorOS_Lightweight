﻿# Debate
- strengths:
- weaknesses:
- counterpoints:

